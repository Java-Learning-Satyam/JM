public class DayOfWeek  {
    public static void main(String[] args) {
        printDayOfWeek(2);
    }
    public static void printDayOfWeek(int day) {
        String dayOfTheWeek = switch (day) {
          case 1 -> "Monday";
          case 2 -> "Tuesday";
          case 3 -> "Wednesday";
          case 4 -> "Thursday";
          case 5 -> "Friday";
          case 6 -> "Saturday";
          case 0 -> "Sunday";
          default -> "invalid day";
        };
        System.out.println("The day of week is " + dayOfTheWeek);
    }
}
