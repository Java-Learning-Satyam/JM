public class InheritanceChellange {
    public static void main(String[] args) {
        SalariedEmployee sam = new SalariedEmployee("Sam","17/7/2003","01/01/2020",35000);
        System.out.println(sam);
        System.out.println("Age = "+sam.getAge());
        System.out.println("Pay = " + sam.collectPay());
        System.out.println("Sam, collect pay " + sam.collectPay());
        sam.retire();
    }
}
class Worker{
    private String name;
    private String birthDate;
    protected String endDate;

    public Worker(String name, String birthDate) {
        this.name = name;
        this.birthDate = birthDate;
    }

    public Worker() {
    }

    public int getAge(){
        int currentYear = 2023;
        int birthYear = Integer.parseInt(birthDate.substring(6));
        return (currentYear - birthYear);

    }
    public double collectPay(){
        return 0.0;
    }

    public void terminate(String endDate){
        this.endDate =endDate;
    }

    @Override
    public String toString() {
        return "Worker{" +
                "name='" + name + '\'' +
                ", birthDate='" + birthDate + '\'' +
                ", endDate='" + endDate + '\'' +
                '}';
    }
}

class Employee extends  Worker{
    private long employeeId;
    private String hireDate;

    private static int employeeNO = 1;

    public Employee(String name, String birthDate, String hireDate) {
        super(name, birthDate);
        this.employeeId = Employee.employeeNO++;
        this.hireDate = hireDate;
    }

    public Employee (){

    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", hireDate='" + hireDate + '\'' +
                "} " + super.toString();
    }
}

class SalariedEmployee extends Employee {
    private double anualSalary;
    private Boolean isRetired;

    public SalariedEmployee() {}

    public SalariedEmployee(String name, String birthDate,  String hireDate,double anualSalary) {
        super(name, birthDate, hireDate);
        this.anualSalary = anualSalary;
    }

    @Override
    public double collectPay(){
        return (int) anualSalary/26;
    }
    public void retire(){
        terminate("12/12/2025");
        isRetired = true;
    }
}

class HourlyEmployee extends Employee{
    private double hourlyPayRate;

    public HourlyEmployee(String name, String birthDate, String hireDate, double hourlyPayRate){
        super(name, birthDate, hireDate);
        this.hourlyPayRate = hourlyPayRate;
    }

    private void getDoublePay() {

    }
}
