package dev.lpa;

import jdk.dynalink.linker.LinkerServices;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        StringBuilder bobsNotes = new StringBuilder();
        StringBuilder satyamsNotes = new StringBuilder("Stayam struggles with collection framework");

        Student bob = new Student("Bob", bobsNotes);
        Student satyam = new Student("Satyam", satyamsNotes);

        List<Student> students = new ArrayList<>(List.of(bob,satyam));
        List<Student> studentsFirstCopy = new ArrayList<>(students);
        List<Student> studentSecondCopy = List.copyOf(students);
        List<Student> studentsThirdCopy = Collections.unmodifiableList(students);

        studentsFirstCopy.add(new Student("Bonnie", new StringBuilder()));
//        studentsSecondCopy.add(new Student("Bonnie", new StringBuilder()));
        studentsFirstCopy.sort(Comparator.comparing(Student::getName));
        students.add(new Student("Bonnie", new StringBuilder()));
        bobsNotes.append("Bob was one of my first Students");

        StringBuilder boniesnotes = studentsFirstCopy.get(2).getStudentNotes();
        boniesnotes.append("Bonnie is taking 3 of my courses");

        students.forEach(System.out::println);
        System.out.println();
        studentsFirstCopy.forEach(System.out::println);
        System.out.println();
        studentSecondCopy.forEach(System.out::println);
        System.out.println();
        studentsThirdCopy.forEach(System.out::println);
        System.out.println();
    }
}
