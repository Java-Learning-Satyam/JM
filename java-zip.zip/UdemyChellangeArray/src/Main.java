import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
     int[] first = {106,26,81,5,15};
        printArray(first);
        for (int element: sortIntegers(first)) {
            System.out.println(element);
        }


    }

    public static int[] getIntegers(int num) {
        return new int[num];
    }
    public static void printArray(int[] arrayin) {
        int len = arrayin.length;
        for (int i = 0; i < len; i++) {
            System.out.println("Element " + i + " contents " + arrayin[i]);
        }
    }
    public static int[] sortIntegers (int[] unsortedArray) {
        Arrays.sort(unsortedArray);
        int len = unsortedArray.length;
        int temp;
        int[] copy = Arrays.copyOf(unsortedArray,len);
        for (int i = len - 1  ; i > 0 ;i-- ){
            temp = unsortedArray[i];
            for (int j = 0; j < len;j++) {
                copy[j] = temp;
            }
        }
        return copy;
    }
}
