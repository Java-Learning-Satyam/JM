public class Main {
    public static void main(String[] args) {
        int myVariable = 50;

        myVariable++; //whole line as statement , except ; an expression
        myVariable--;

        System.out.println("This is " +
                "also a statement " +
                "but scatterd over line's");
    }
}
