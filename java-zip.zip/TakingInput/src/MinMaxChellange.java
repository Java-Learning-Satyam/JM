import java.util.Scanner;

public class MinMaxChellange {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int min = 0 ,max = 0;
        int previous , currentNumber = 0 ,count = 0;

        do {
            previous = currentNumber;

            System.out.println("Enter a number ");
            System.out.println("Repeated number to exit or character to exit ");
            String read = scanner.nextLine();

            try {
                currentNumber = Integer.parseInt(read);
                if (count == 0 || currentNumber < min) {
                    min = currentNumber;
                }
                if (count == 0 ||currentNumber > max) {
                    max = currentNumber;
                }
                count++;
            } catch(NumberFormatException nfe) {
                break;
            }


        } while (previous != currentNumber);
        if (count > 0){
            System.out.println("minimum among all was : " + min + " maximum among all was : " + max);
        }else {
            System.out.println("No valid data Enterd");
        }
    }
}
