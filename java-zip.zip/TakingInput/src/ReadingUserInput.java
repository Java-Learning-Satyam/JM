import java.util.Scanner;

public class ReadingUserInput {
    public static void main(String[] args) {

        int count = 1;
        double numTotal = 0;
        double total = 0;

        Scanner scanner = new Scanner(System.in);
        do {

            System.out.println("Enter number #" + count);
            String readNumber = scanner.nextLine();
            try {
//            total = Integer.parseInt(readNumber);
                numTotal = Double.parseDouble(readNumber);
                numTotal = total + numTotal;
//            System.out.println(numTotal);

        } catch (NumberFormatException badUserData){

                System.out.println("Invalid Number");
                count--;

            }
            count++;
        } while (count <= 5);

        System.out.println("Total of Number's is " + numTotal);
    }
}
